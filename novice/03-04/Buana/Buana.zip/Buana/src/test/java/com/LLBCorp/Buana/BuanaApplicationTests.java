package com.LLBCorp.Buana;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuanaApplicationTests {

	@Test
	void contextLoads() {
	}

}
